import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ShareTaskAndDateService } from '../share-task-and-date.service';

@Component({
  selector: 'app-open-form',
  templateUrl: './open-form.component.html',
  styleUrls: ['./open-form.component.css']
})
export class OpenFormComponent implements OnInit {
showError:boolean=false;
  constructor(public dialogRef: MatDialogRef<OpenFormComponent>,private share:ShareTaskAndDateService) { }

  ngOnInit(): void {
  }
  addTask(task:any,date:any){
    this.share.getTaskAndDate(task,date);
    this.dialogRef.close();
  }



}
