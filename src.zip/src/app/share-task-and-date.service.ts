import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShareTaskAndDateService {
task:any="";
date:any="";
currDate:any="";

  private apiUrl = 'http://localhost:3000';
  constructor(private http: HttpClient) { }

  getTaskAndDate(utask:any,udate:any){
this.task=utask;
this.date=udate;
  }

  setTask(){
    return this.task;
  }

  setDate() {
    return this.date;
  }
  updateData(): Observable<any> {
   
    const newData = {
      date: this.date,
      tasks: [this.task],
      cdate:this.currDate
    };
    console.log(this.date);
    return this.http.post(`${this.apiUrl}/updateData`, newData);
  
  }

 getCurrDate(currdate:any){
this.currDate=currdate;
 }
 setCurrDate(){
  return this.currDate;
 }


  deleteData(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/deleteData`, data);
  }
}
