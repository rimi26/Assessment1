import { Component , OnInit} from '@angular/core';
import { ShareTaskAndDateService } from './share-task-and-date.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'calenderscheduler';
  isCurrentDate:boolean=false;
  showError:boolean=false;
  errorSentence:any="";

 ngOnInit(): void {
 
 }
    pages: any[][] = [
      [{ name: 'SUN', date: '29', cdate: '29/10/2023', isCurrentDate: false }, { name: 'MON', date: '30', cdate: '30/10/2023', isCurrentDate: false }, { name: 'TUE', date: '31', cdate: '31/10/2023', isCurrentDate: false }, { name: 'WED', date: '01', cdate: '01/11/2023', isCurrentDate: false }, { name: 'THU', date: '02', cdate: '02/11/2023', isCurrentDate: false }, { name: 'FRI', date: '03', cdate: '03/11/2023', isCurrentDate: false }, { name: 'SAT', date: '04', cdate: '04/11/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '05', cdate: '05/11/2023', isCurrentDate: false }, { name: 'MON', date: '06', cdate: '06/11/2023', isCurrentDate: false }, { name: 'TUE', date: '07', cdate: '07/11/2023', isCurrentDate: false }, { name: 'WED', date: '08', cdate: '08/11/2023', isCurrentDate: false }, { name: 'THU', date: '09', cdate: '09/11/2023', isCurrentDate: false }, { name: 'FRI', date: '10', cdate: '10/11/2023', isCurrentDate: false }, { name: 'SAT', date: '11', cdate: '11/11/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '12', cdate: '12/11/2023', isCurrentDate: false }, { name: 'MON', date: '13', cdate: '13/11/2023', isCurrentDate: false }, { name: 'TUE', date: '14', cdate: '14/11/2023', isCurrentDate: false }, { name: 'WED', date: '15', cdate: '15/11/2023', isCurrentDate: false }, { name: 'THU', date: '16', cdate: '16/11/2023', isCurrentDate: false }, { name: 'FRI', date: '17', cdate: '17/11/2023', isCurrentDate: false }, { name: 'SAT', date: '28', cdate: '28/11/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '19', cdate: '19/11/2023', isCurrentDate: false }, { name: 'MON', date: '20', cdate: '20/11/2023', isCurrentDate: false }, { name: 'TUE', date: '21', cdate: '21/11/2023', isCurrentDate: false }, { name: 'WED', date: '22', cdate: '22/11/2023', isCurrentDate: false }, { name: 'THU', date: '23', cdate: '23/11/2023', isCurrentDate: false }, { name: 'FRI', date: '24', cdate: '24/11/2023', isCurrentDate: false }, { name: 'SAT', date: '25', cdate: '25/11/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '26', cdate: '26/11/2023', isCurrentDate: false }, { name: 'MON', date: '27', cdate: '27/11/2023', isCurrentDate: false }, { name: 'TUE', date: '28', cdate: '28/11/2023', isCurrentDate: false }, { name: 'WED', date: '29', cdate: '29/11/2023', isCurrentDate: false }, { name: 'THU', date: '30', cdate: '30/11/2023', isCurrentDate: false }, { name: 'FRI', date: '01', cdate: '01/12/2023', isCurrentDate: false }, { name: 'SAT', date: '02', cdate: '02/12/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '03', cdate: '03/12/2023', isCurrentDate: false }, { name: 'MON', date: '04', cdate: '04/12/2023', isCurrentDate: false }, { name: 'TUE', date: '05', cdate: '05/12/2023', isCurrentDate: false }, { name: 'WED', date: '06', cdate: '06/12/2023', isCurrentDate: false }, { name: 'THU', date: '07', cdate: '07/12/2023', isCurrentDate: false }, { name: 'FRI', date: '08', cdate: '08/12/2023', isCurrentDate: false }, { name: 'SAT', date: '09', cdate: '09/12/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '10', cdate: '10/12/2023', isCurrentDate: false }, { name: 'MON', date: '11', cdate: '11/12/2023', isCurrentDate: false }, { name: 'TUE', date: '12', cdate: '12/12/2023', isCurrentDate: false }, { name: 'WED', date: '13', cdate: '13/12/2023', isCurrentDate: false }, { name: 'THU', date: '14', cdate: '14/12/2023', isCurrentDate: false }, { name: 'FRI', date: '15', cdate: '15/12/2023', isCurrentDate: false }, { name: 'SAT', date: '16', cdate: '16/12/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '17', cdate: '17/12/2023', isCurrentDate: false }, { name: 'MON', date: '18', cdate: '18/12/2023', isCurrentDate: false }, { name: 'TUE', date: '19', cdate: '19/12/2023', isCurrentDate: false }, { name: 'WED', date: '20', cdate: '20/12/2023', isCurrentDate: false }, { name: 'THU', date: '21', cdate: '21/12/2023', isCurrentDate: false }, { name: 'FRI', date: '22', cdate: '22/12/2023', isCurrentDate: false }, { name: 'SAT', date: '23', cdate: '23/12/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '24', cdate: '24/12/2023', isCurrentDate: false }, { name: 'MON', date: '25', cdate: '25/12/2023', isCurrentDate: false }, { name: 'TUE', date: '26', cdate: '26/12/2023', isCurrentDate: false }, { name: 'WED', date: '27', cdate: '27/12/2023', isCurrentDate: false }, { name: 'THU', date: '28', cdate: '28/12/2023', isCurrentDate: false }, { name: 'FRI', date: '29', cdate: '29/12/2023', isCurrentDate: false }, { name: 'SAT', date: '30', cdate: '30/12/2023', isCurrentDate: false }],
      [{ name: 'SUN', date: '31', cdate: '31/12/2023', isCurrentDate: false }, { name: 'MON', date: '01', cdate: '01/01/2024', isCurrentDate: false }, { name: 'TUE', date: '02', cdate: '02/01/2024', isCurrentDate: false }, { name: 'WED', date: '03', cdate: '03/01/2024', isCurrentDate: false }, { name: 'THU', date: '04', cdate: '04/01/2024', isCurrentDate: false }, { name: 'FRI', date: '05', cdate: '05/01/2024', isCurrentDate: false }, { name: 'SAT', date: '06', cdate: '06/01/2024', isCurrentDate: false }] 
      
    ];

  buttons: { buttonVisible: boolean; componentVisible: boolean }[][] = [];

  currentPageIndex: number = 0;
  currentDate: string;
  constructor(private share:ShareTaskAndDateService) {
    const today = new Date();
    this.currentDate = today.toLocaleDateString();
    console.log(this.currentDate)
    this.initializeButtons();
  
    for (const page of this.pages) {
      for (const item of page) {
        if (this.currentDate == item.cdate){
          item.isCurrentDate=true;
          this.share.getCurrDate(item.cdate);
        }
         else{
          item.isCurrentDate = false;
         }
      }
    }
    
   
  }

   
  UpdateData(): Observable<boolean> {
    return new Observable<boolean>((observer) => {
      this.share.updateData().subscribe(
        (response) => {
          console.log('Response from server:', response);
          observer.next(true);
          observer.complete();
        },
        (error) => {
          console.error('Error from server:', error);
          observer.next(false);
          observer.complete();
        }
      );
    });
  }



  initializeButtons() {
    
    this.buttons = Array.from({ length: 10 }, (_, rowIndex) =>
      Array.from({ length: 7 }, (_, cellIndex) => ({
        
        buttonVisible: rowIndex === 0 && this.parseDateString(this.currentDate) <= this.parseDateString(this.pages[this.currentPageIndex][cellIndex].cdate),
        componentVisible: false
      })
      )
    );
  }
  private parseDateString(dateString: string): Date {
    const parts = dateString.split('/');
    return new Date(+parts[2], +parts[1] - 1, +parts[0]);
  }
 

  prev(){
    if (this.currentPageIndex > 0) {
      this.currentPageIndex--;
      console.log('Previous Page. New Index:', this.currentPageIndex);
      
      this.initializeButtons();
      for (let i = 0; i < this.pages[this.currentPageIndex].length; i++) {
        if (this.currentDate === this.pages[this.currentPageIndex][i].cdate) {
          this.isCurrentDate = true;
        }
        if (this.currentDate != this.pages[this.currentPageIndex][i].cdate) {
          this.isCurrentDate = false;
        }
      }
    }
  }
  next(){
    if (this.currentPageIndex < this.pages.length - 1) {
      this.currentPageIndex++;
      console.log('Next Page. New Index:', this.currentPageIndex);
      for (let i = 0; i < this.pages[this.currentPageIndex].length; i++) {
        if (this.currentDate === this.pages[this.currentPageIndex][i].cdate) {
          this.isCurrentDate = true;
        }
        if (this.currentDate != this.pages[this.currentPageIndex][i].cdate) {
          this.isCurrentDate = false;
        }
      }
      this.initializeButtons();
    }
  }

 

  handleButtonClick(row: number, cell: number) {
    console.log(this.share.setDate());
    console.log(this.pages[this.currentPageIndex][cell].cdate);
    if (this.share.setDate() == this.pages[this.currentPageIndex][cell].cdate){
      console.log("matched");
      this.UpdateData().subscribe((willUpdate) => {
        // Use willUpdate value here
        console.log(willUpdate);
        if(willUpdate){
          if (row < this.buttons.length - 1) {
            this.showError = false;
            if (this.buttons[row + 1][cell].componentVisible != true) {
              this.buttons[row][cell].buttonVisible = false;
              this.buttons[row + 1][cell].buttonVisible = true;
              this.buttons[row][cell].componentVisible = true;
            } else {
              this.buttons[row][cell].buttonVisible = false;
              this.buttons[row][cell].componentVisible = true;
            }
          }

        }else{
               this.errorSentence="This task is already there.Please choose different task"
               this.showError = true;
        }
      });
      
    
    }
    if (this.share.setDate() != this.pages[this.currentPageIndex][cell].cdate) {
      this.errorSentence = "Please Enter Today's Date"
      this.showError=true;  
    }
    
  }

  handleCustomEvent(row: number, cell: number,event:any) {
    console.log(event);
    console.log(this.pages[this.currentPageIndex][cell].cdate);
    this.deleteData(this.pages[this.currentPageIndex][cell].cdate,event)
    if (row < this.buttons.length - 1) {
      this.buttons[row][cell].buttonVisible = true;
      this.buttons[row + 1][cell].buttonVisible = false;
      this.buttons[row][cell].componentVisible = false;
    }
  }
  
  deleteData(udate:any,utask:any) {
    const deleteData = { date: udate, tasks: [utask] };
    this.share.deleteData(deleteData).subscribe(
      (response) => console.log(response),
      (error) => console.error(error)
    );
  }
}
