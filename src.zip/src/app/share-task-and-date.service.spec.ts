import { TestBed } from '@angular/core/testing';

import { ShareTaskAndDateService } from './share-task-and-date.service';

describe('ShareTaskAndDateService', () => {
  let service: ShareTaskAndDateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShareTaskAndDateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
