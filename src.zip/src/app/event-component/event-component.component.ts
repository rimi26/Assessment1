import { Component, OnInit ,Output,EventEmitter,ViewChild,ElementRef} from '@angular/core';
import { ShareTaskAndDateService } from '../share-task-and-date.service';
@Component({
  selector: 'app-event-component',
  templateUrl: './event-component.component.html',
  styleUrls: ['./event-component.component.css']
})
export class EventComponentComponent implements OnInit {
  @Output() customEvent: EventEmitter<string> = new EventEmitter<string>();
  @Output() customEvent1: EventEmitter<string> = new EventEmitter<string>();
  taskName:any='';
  @ViewChild('task', { static: true })
  label!: ElementRef;
  emitEvent() {
    const taskname = this.label.nativeElement.innerText;
    console.log(taskname);
    this.customEvent.emit(taskname);
  }
  constructor(private share:ShareTaskAndDateService) { }
show:boolean=true;
  ngOnInit(): void {
    this.taskName=this.share.setTask();
    console.log("initiated");
  }
  completed(){
   
      this.show = false;
      this.isActive = true;
    

  }
  

  isActive:boolean=false;
}
