import { Component, OnInit,Output,EventEmitter,Input ,ViewChild,ElementRef} from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { OpenFormComponent } from '../open-form/open-form.component';
import { ShareTaskAndDateService } from '../share-task-and-date.service';

@Component({
  selector: 'app-button-component',
  templateUrl: './button-component.component.html',
  styleUrls: ['./button-component.component.css']
})
export class ButtonComponentComponent implements OnInit {
  @Input() isVisible: boolean = true;
  @Output() buttonClick: EventEmitter<void> = new EventEmitter<void>();

  constructor(private dialog:MatDialog,private share:ShareTaskAndDateService) { }
  
  openForm(){
    console.log("clicked");
    const dialogRef = this.dialog.open(OpenFormComponent, {
      width: '250px',
    });
 
    dialogRef.afterClosed().subscribe(() => {
 
      console.log("dialog closed");
      if (this.share.setTask() != '' && this.share.setDate() != ''){
        this.handleButtonClick();
      }
      
    });
  }
    handleButtonClick() {
this.buttonClick.emit();
  }
  ngOnInit(): void {
  }

}


